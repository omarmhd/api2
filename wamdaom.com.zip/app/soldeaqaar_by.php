<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class soldeaqaar_by extends Model
{
    //
}
